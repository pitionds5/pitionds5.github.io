// ===================================================
// ALL ABOUT MTA - COMPLETE FIXED DASHBOARD
// ===================================================

// Categories with real-time counts
const CATEGORIES = [
    { id: 'maps', name: 'Maps', icon: 'fas fa-map', color: '#0fbcf9', count: 0 },
    { id: 'mods', name: 'Mods', icon: 'fas fa-cogs', color: '#00ff88', count: 0 },
    { id: 'scripts', name: 'Scripts', icon: 'fas fa-code', color: '#ff6b8b', count: 0 },
    { id: 'skins', name: 'Skins', icon: 'fas fa-user', color: '#ffc107', count: 0 },
    { id: 'vehicles', name: 'Vehicles', icon: 'fas fa-car', color: '#9c27b0', count: 0 },
    { id: 'objects', name: 'Objects', icon: 'fas fa-cube', color: '#4caf50', count: 0 },
    { id: 'hud', name: 'HUD', icon: 'fas fa-tachometer-alt', color: '#ff5722', count: 0 },
    { id: 'backups', name: 'Backups', icon: 'fas fa-save', color: '#607d8b', count: 0 }
];

// Global variables
let currentUser = null;
let userRole = 'user';
let db = null;
let currentCategory = null; // Track current selected category

// ==================== INITIALIZATION ====================
function initializeDashboard() {
    console.log('🚀 Initializing Real Dashboard...');
    
    try {
        // Firebase config
        const firebaseConfig = {
            apiKey: "AIzaSyDEIJlanhg5yZ83kqFyD5uCpj2hg99a5A8",
            authDomain: "mta-web-5a05d.firebaseapp.com",
            projectId: "mta-web-5a05d",
            storageBucket: "mta-web-5a05d.firebasestorage.app",
            messagingSenderId: "203869887586",
            appId: "1:203869887586:web:fbaa16e45ffcee385cc53b",
            measurementId: "G-F4V1FJ9WDJ"
        };

        // Initialize Firebase
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        
        db = firebase.firestore();
        const auth = firebase.auth();
        
        console.log('✅ Firebase initialized');
        
        // Load everything
        loadCategories();
        loadResources(); // Load recent resources by default
        
        // Auth listener
        auth.onAuthStateChanged(async (user) => {
            if (user) {
                currentUser = {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName || user.email.split('@')[0]
                };
                
                // Update UI
                document.getElementById('userEmail').textContent = user.email;
                
                // Check admin status
                await checkAdminStatus();
                
                // Load favorites
                loadFavorites();
                
            } else {
                console.log('No user found');
            }
        });
        
        // Setup logout
        document.getElementById('signOutBtn').addEventListener('click', () => {
            auth.signOut();
        });
        
        // Setup view toggle buttons
        setupViewToggle();
        
    } catch (error) {
        console.error('❌ Initialization error:', error);
        showMessage('Failed to initialize. Please refresh.', 'error');
    }
}

// ==================== LOAD CATEGORIES WITH REAL COUNTS ====================
async function loadCategories() {
    const container = document.getElementById('categoriesGrid');
    if (!container) return;
    
    // Clear and show loading
    container.innerHTML = '<div class="category-loading"><div class="loader"></div><p>Loading categories...</p></div>';
    
    try {
        // First, get ALL resources to count properly
        const resourcesSnapshot = await db.collection('resources')
            .where('approved', '==', true)
            .get();
        
        // Count resources per category
        const categoryCounts = {};
        CATEGORIES.forEach(cat => categoryCounts[cat.id] = 0);
        
        resourcesSnapshot.forEach(doc => {
            const resource = doc.data();
            if (resource.category && categoryCounts[resource.category] !== undefined) {
                categoryCounts[resource.category]++;
            }
        });
        
        // Update category counts
        CATEGORIES.forEach(cat => {
            cat.count = categoryCounts[cat.id] || 0;
        });
        
        // Now render categories with correct counts
        renderCategories();
        
        // Setup category click handlers
        setupCategoryClicks();
        
    } catch (error) {
        console.error('Error loading categories:', error);
        // Still render categories with 0 counts
        renderCategories();
    }
}

function renderCategories() {
    const container = document.getElementById('categoriesGrid');
    if (!container) return;
    
    container.innerHTML = '';
    
    CATEGORIES.forEach(category => {
        const card = document.createElement('div');
        card.className = 'category-card';
        card.dataset.category = category.id;
        
        // Highlight if selected
        if (currentCategory === category.id) {
            card.style.borderColor = category.color;
            card.style.boxShadow = `0 0 15px ${category.color}40`;
        }
        
        card.innerHTML = `
            <div class="category-icon" style="background: rgba(${hexToRgb(category.color)}, 0.1); color: ${category.color}">
                <i class="${category.icon}"></i>
            </div>
            <div class="category-name">${category.name}</div>
            <div class="category-count">${category.count} ${category.count === 1 ? 'item' : 'items'}</div>
        `;
        
        container.appendChild(card);
    });
}

function setupCategoryClicks() {
    const categoryCards = document.querySelectorAll('.category-card');
    
    categoryCards.forEach(card => {
        card.addEventListener('click', function() {
            const categoryId = this.dataset.category;
            
            // Update current category
            currentCategory = categoryId;
            
            // Update UI to show selected category
            document.querySelectorAll('.category-card').forEach(c => {
                c.style.borderColor = '';
                c.style.boxShadow = '';
            });
            
            this.style.borderColor = CATEGORIES.find(c => c.id === categoryId).color;
            this.style.boxShadow = `0 0 15px ${CATEGORIES.find(c => c.id === categoryId).color}40`;
            
            // Load resources for this category
            loadResourcesByCategory(categoryId);
            
            // Update panel title
            const categoryName = CATEGORIES.find(c => c.id === categoryId).name;
            const resourcesPanel = document.querySelector('.resources-panel h2');
            if (resourcesPanel) {
                resourcesPanel.innerHTML = `<i class="fas fa-filter"></i> ${categoryName.toUpperCase()} RESOURCES`;
            }
        });
    });
}

// ==================== LOAD RESOURCES ====================
async function loadResources() {
    const container = document.getElementById('resourcesContainer');
    if (!container) return;
    
    // Show loading
    container.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
            <div class="loader"></div>
            <p>Loading resources...</p>
        </div>
    `;
    
    try {
        const snapshot = await db.collection('resources')
            .where('approved', '==', true)
            .orderBy('uploadedAt', 'desc')
            .limit(12)
            .get();
        
        displayResources(snapshot);
        
    } catch (error) {
        console.error('Error loading resources:', error);
        showNoResources('Failed to load resources');
    }
}

async function loadResourcesByCategory(categoryId) {
    const container = document.getElementById('resourcesContainer');
    if (!container) return;
    
    // Show loading
    container.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
            <div class="loader"></div>
            <p>Loading ${CATEGORIES.find(c => c.id === categoryId).name}...</p>
        </div>
    `;
    
    try {
        const snapshot = await db.collection('resources')
            .where('category', '==', categoryId)
            .where('approved', '==', true)
            .orderBy('uploadedAt', 'desc')
            .get();
        
        if (snapshot.empty) {
            const categoryName = CATEGORIES.find(c => c.id === categoryId).name;
            showNoResources(`No ${categoryName.toLowerCase()} found yet.`);
            return;
        }
        
        displayResources(snapshot);
        
    } catch (error) {
        console.error('Error loading category resources:', error);
        showNoResources('Failed to load category');
    }
}

function displayResources(snapshot) {
    const container = document.getElementById('resourcesContainer');
    container.innerHTML = '';
    
    if (snapshot.empty) {
        showNoResources('No resources found');
        return;
    }
    
    snapshot.forEach(doc => {
        const resource = { id: doc.id, ...doc.data() };
        container.appendChild(createResourceCard(resource));
    });
}

function showNoResources(message = 'No resources found') {
    const container = document.getElementById('resourcesContainer');
    container.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-box-open"></i>
            <h3>${message}</h3>
            <p>${currentCategory ? 
                `Be the first to upload a ${CATEGORIES.find(c => c.id === currentCategory).name.toLowerCase()}!` : 
                'Be the first to upload a resource!'}
            </p>
            ${userRole === 'admin' ? 
                '<button class="btn-admin" onclick="window.location.href=\'admin-upload.html\'" style="margin-top: 15px;"><i class="fas fa-upload"></i> UPLOAD NOW</button>' : 
                ''}
        </div>
    `;
}

// ==================== CREATE RESOURCE CARD ====================
function createResourceCard(resource) {
    const card = document.createElement('div');
    card.className = 'resource-card';
    card.dataset.id = resource.id;
    
    // Check if favorited
    let isFavorited = false;
    if (currentUser && currentUser.favorites) {
        isFavorited = currentUser.favorites.includes(resource.id);
    }
    
    // Format date
    let dateString = 'Recently';
    if (resource.uploadedAt && resource.uploadedAt.toDate) {
        const date = resource.uploadedAt.toDate();
        dateString = formatDate(date);
    }
    
    card.innerHTML = `
        <div class="resource-image">
            ${resource.imageUrl ? 
                `<img src="${resource.imageUrl}" alt="${resource.name}" 
                      onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fas fa-${getCategoryIcon(resource.category)}\\'></i>'">` : 
                `<i class="fas fa-${getCategoryIcon(resource.category)}"></i>`
            }
        </div>
        <div class="resource-content">
            <div class="resource-header">
                <div class="resource-title">${resource.name}</div>
                <button class="favorite-btn ${isFavorited ? 'active' : ''}" 
                        onclick="toggleFavorite('${resource.id}', this)">
                    <i class="${isFavorited ? 'fas' : 'far'} fa-star"></i>
                </button>
            </div>
            <div class="resource-meta">
                <span class="resource-category">${getCategoryName(resource.category)}</span>
                <span><i class="fas fa-download"></i> ${resource.downloads || 0}</span>
                <span><i class="fas fa-calendar"></i> ${dateString}</span>
            </div>
            <div class="resource-description">
                ${resource.description ? (resource.description.length > 100 ? 
                    resource.description.substring(0, 100) + '...' : 
                    resource.description) : 'No description'}
            </div>
            <div class="resource-actions">
                <button class="btn-download" onclick="downloadResource('${resource.id}', '${resource.downloadUrl}')">
                    <i class="fas fa-download"></i> DOWNLOAD
                </button>
                <button class="btn-preview" onclick="previewResource('${resource.id}')">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
        </div>
    `;
    
    return card;
}

// ==================== FAVORITES ====================
async function toggleFavorite(resourceId, button) {
    if (!currentUser || !db) {
        showMessage('Please login to add favorites', 'error');
        return;
    }
    
    try {
        const userRef = db.collection('users').doc(currentUser.uid);
        const userDoc = await userRef.get();
        const currentFavorites = userDoc.data()?.favorites || [];
        
        if (currentFavorites.includes(resourceId)) {
            // Remove from favorites
            await userRef.update({
                favorites: firebase.firestore.FieldValue.arrayRemove(resourceId)
            });
            button.querySelector('i').className = 'far fa-star';
            button.classList.remove('active');
            showMessage('Removed from favorites', 'success');
        } else {
            // Add to favorites
            await userRef.update({
                favorites: firebase.firestore.FieldValue.arrayUnion(resourceId)
            });
            button.querySelector('i').className = 'fas fa-star';
            button.classList.add('active');
            showMessage('Added to favorites', 'success');
        }
        
        // Update favorites display
        loadFavorites();
        
    } catch (error) {
        console.error('Favorite error:', error);
        showMessage('Failed to update favorites', 'error');
    }
}

async function loadFavorites() {
    const container = document.getElementById('favoritesContainer');
    if (!container) return;
    
    if (!currentUser || !db) {
        container.innerHTML = `
            <div class="empty-favorites">
                <i class="far fa-star"></i>
                <p>Login to see favorites</p>
            </div>
        `;
        return;
    }
    
    try {
        const userDoc = await db.collection('users').doc(currentUser.uid).get();
        const favorites = userDoc.data()?.favorites || [];
        
        if (favorites.length === 0) {
            container.innerHTML = `
                <div class="empty-favorites">
                    <i class="far fa-star"></i>
                    <p>No favorites yet. Click the star on any resource.</p>
                </div>
            `;
            return;
        }
        
        // Get favorite resources
        const favoritePromises = favorites.map(id => 
            db.collection('resources').doc(id).get()
        );
        
        const favoritesSnap = await Promise.all(favoritePromises);
        container.innerHTML = '';
        
        favoritesSnap.forEach(doc => {
            if (doc.exists) {
                const resource = { id: doc.id, ...doc.data() };
                container.appendChild(createResourceCard(resource));
            }
        });
        
    } catch (error) {
        console.error('Error loading favorites:', error);
        container.innerHTML = `
            <div class="empty-favorites">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading favorites</p>
            </div>
        `;
    }
}

// ==================== ADMIN SYSTEM ====================
async function checkAdminStatus() {
    if (!currentUser || !db) return;
    
    try {
        const userDoc = await db.collection('users').doc(currentUser.uid).get();
        
        if (userDoc.exists) {
            userRole = userDoc.data().role || 'user';
            
            // Update UI
            const roleElement = document.getElementById('userRole');
            if (roleElement) {
                roleElement.textContent = userRole.toUpperCase();
            }
            
            // Show admin controls if admin
            if (userRole === 'admin') {
                const adminControls = document.getElementById('adminControls');
                if (adminControls) {
                    adminControls.style.display = 'block';
                    
                    // Setup admin buttons
                    const uploadBtn = document.getElementById('uploadBtn');
                    const manageBtn = document.getElementById('manageBtn');
                    
                    if (uploadBtn) {
                        uploadBtn.onclick = () => window.location.href = 'admin-upload.html';
                    }
                    
                    if (manageBtn) {
                        manageBtn.onclick = () => showMessage('Content management coming soon', 'info');
                    }
                }
            }
        }
        
    } catch (error) {
        console.error('Admin check error:', error);
    }
}

// ==================== VIEW TOGGLE ====================
function setupViewToggle() {
    const viewButtons = document.querySelectorAll('.view-btn');
    
    viewButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            // Update active state
            viewButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Change view
            const viewType = this.dataset.view;
            const container = document.getElementById('resourcesContainer');
            
            if (viewType === 'list') {
                container.classList.add('list-view');
            } else {
                container.classList.remove('list-view');
            }
        });
    });
}

// ==================== UTILITY FUNCTIONS ====================
function getCategoryIcon(categoryId) {
    const category = CATEGORIES.find(c => c.id === categoryId);
    return category ? category.icon.split(' ')[1].replace('fa-', '') : 'file';
}

function getCategoryName(categoryId) {
    const category = CATEGORIES.find(c => c.id === categoryId);
    return category ? category.name : 'Unknown';
}

function hexToRgb(hex) {
    hex = hex.replace('#', '');
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    return `${r}, ${g}, ${b}`;
}

function formatDate(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffHours < 168) return `${Math.floor(diffHours / 24)}d ago`;
    
    return date.toLocaleDateString();
}

function downloadResource(resourceId, url) {
    if (!url || url === '#') {
        showMessage('Download link not available', 'error');
        return;
    }
    
    // Open download
    window.open(url, '_blank');
    showMessage('Download started', 'success');
    
    // Increment download count
    if (db) {
        db.collection('resources').doc(resourceId).update({
            downloads: firebase.firestore.FieldValue.increment(1)
        }).catch(err => console.error('Download count error:', err));
    }
}

// ==================== AVATAR SYSTEM ====================
function setupUserAvatar(user) {
    const avatarElement = document.querySelector('.user-avatar');
    if (!avatarElement) return;
    
    // Clear existing content
    avatarElement.innerHTML = '';
    
    // Check if user has photo (Google login)
    if (user.photoURL) {
        // Use Google/Discord avatar
        avatarElement.innerHTML = `
            <img src="${user.photoURL}" 
                 alt="${user.displayName || 'User'}" 
                 style="width:100%;height:100%;border-radius:50%;object-fit:cover;"
                 onerror="this.onerror=null; this.src='assets/default-avatar.jpg'">
        `;
    } else {
        // Use YOUR default avatar
        avatarElement.innerHTML = `
            <img src="assets/default-avatar.jpg" 
                 alt="Default Avatar" 
                 style="width:100%;height:100%;border-radius:50%;object-fit:cover;"
                 onerror="this.onerror=null; this.outerHTML='<div style=\\'width:100%;height:100%;border-radius:50%;background:linear-gradient(135deg, #0fbcf9, #00ff88);display:flex;align-items:center;justify-content:center;\\'><i class=\\'fas fa-user\\' style=\\'color:white;font-size:18px;\\'></i></div>'">
        `;
    }
}

// Also update the auth state listener in dashboard-data.js:
auth.onAuthStateChanged(async (user) => {
    if (user) {
        currentUser = {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || user.email.split('@')[0],
            photoURL: user.photoURL || null
        };
        
        // Update UI
        document.getElementById('userEmail').textContent = user.email;
        
        // Setup avatar - USING YOUR DEFAULT AVATAR
        setupUserAvatar(user);
        
        // Check admin status
        await checkAdminStatus();
        
        // Load favorites
        loadFavorites();
        
    } else {
        console.log('No user found');
    }
});

// ==================== LISTEN FOR UPLOAD UPDATES ====================
function setupUploadListener() {
    // Listen for messages from upload page
    window.addEventListener('message', function(event) {
        if (event.data.type === 'RESOURCE_UPLOADED') {
            console.log('📦 New resource uploaded:', event.data.category);
            
            // Refresh category counts
            updateCategoryCounts();
            
            // Refresh resources if viewing that category
            if (currentCategory === event.data.category) {
                loadResourcesByCategory(currentCategory);
            } else {
                loadResources(); // Refresh recent resources
            }
            
            showMessage('New resource added!', 'success');
        }
    });
    
    // Check localStorage for recent uploads
    setInterval(() => {
        const lastUploadTime = localStorage.getItem('last_upload_time');
        const lastUploadCategory = localStorage.getItem('last_upload_category');
        
        if (lastUploadTime && lastUploadCategory) {
            const uploadTime = parseInt(lastUploadTime);
            const now = new Date().getTime();
            
            // If upload was within last 10 seconds
            if (now - uploadTime < 10000) {
                console.log('🔄 Detected recent upload, refreshing...');
                
                // Refresh data
                updateCategoryCounts();
                
                if (currentCategory === lastUploadCategory) {
                    loadResourcesByCategory(currentCategory);
                } else {
                    loadResources();
                }
                
                // Clear the flag
                localStorage.removeItem('last_upload_time');
                localStorage.removeItem('last_upload_category');
            }
        }
    }, 2000);
}

// Call this in initializeDashboard():
// setupUploadListener();

function previewResource(resourceId) {
    // Will implement modal preview later
    showMessage('Preview feature coming soon', 'info');
}

function showMessage(text, type = 'info') {
    // Remove existing
    const existing = document.querySelector('.temp-message');
    if (existing) existing.remove();
    
    // Create new
    const message = document.createElement('div');
    message.className = 'temp-message';
    message.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 12px 20px;
        background: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff6b8b' : '#0fbcf9'};
        color: white;
        border-radius: 8px;
        z-index: 9999;
        font-weight: 500;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: slideIn 0.3s ease;
    `;
    message.textContent = text;
    document.body.appendChild(message);
    
    // Auto-remove
    setTimeout(() => {
        message.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => message.remove(), 300);
    }, 3000);
}

// Add CSS animations
if (!document.querySelector('#message-styles')) {
    const style = document.createElement('style');
    style.id = 'message-styles';
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        /* List view styles */
        .resources-container.list-view {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .resources-container.list-view .resource-card {
            display: flex;
            flex-direction: row;
        }
        
        .resources-container.list-view .resource-image {
            width: 120px;
            height: 120px;
            min-width: 120px;
        }
        
        .resources-container.list-view .resource-content {
            flex: 1;
            padding: 15px;
        }
        
        /* Category loading */
        .category-loading {
            grid-column: 1 / -1;
            text-align: center;
            padding: 40px;
            color: var(--mta-text-secondary);
        }
    `;
    document.head.appendChild(style);
}

// Start dashboard
document.addEventListener('DOMContentLoaded', initializeDashboard);