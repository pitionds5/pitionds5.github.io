// ===================================================
// ALL ABOUT MTA - NO LOGIN LOOP VERSION
// ===================================================

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyDEIJlanhg5yZ83kqFyD5uCpj2hg99a5A8",
    authDomain: "mta-web-5a05d.firebaseapp.com",
    projectId: "mta-web-5a05d",
    storageBucket: "mta-web-5a05d.firebasestorage.app",
    messagingSenderId: "203869887586",
    appId: "1:203869887586:web:fbaa16e45ffcee385cc53b",
    measurementId: "G-F4V1FJ9WDJ"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// Track if we're already redirecting
let isRedirecting = false;

// ==================== SHOW MESSAGES ====================
function showMessage(message, type = 'error') {
    const messageElement = document.getElementById('errorMessage');
    if (!messageElement) return;
    
    messageElement.textContent = message;
    messageElement.style.color = type === 'success' ? '#00ff88' : '#ff9e7a';
    messageElement.style.opacity = '1';
    
    if (type === 'success') {
        setTimeout(() => {
            messageElement.style.opacity = '0';
        }, 2000);
    }
}

// ==================== EMAIL/PASSWORD LOGIN ====================
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (isRedirecting) return;
        
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value;
        
        if (!email || !password) {
            showMessage('Please enter both email and password.');
            return;
        }
        
        try {
            // Try to sign in
            const userCredential = await auth.signInWithEmailAndPassword(email, password);
            
            // Save user data
            await saveUserData(userCredential.user);
            
            // Redirect
            isRedirecting = true;
            window.location.href = 'dashboard.html';
            
        } catch (error) {
            // User doesn't exist - create account
            if (error.code === 'auth/user-not-found') {
                try {
                    const userCredential = await auth.createUserWithEmailAndPassword(email, password);
                    await saveUserData(userCredential.user);
                    
                    isRedirecting = true;
                    window.location.href = 'dashboard.html';
                    
                } catch (signupError) {
                    showMessage('Signup failed: ' + signupError.message);
                }
            } else {
                showMessage('Error: ' + error.message);
            }
        }
    });
}

// ==================== GOOGLE LOGIN ====================
if (document.getElementById('googleSignIn')) {
    document.getElementById('googleSignIn').addEventListener('click', function() {
        if (isRedirecting) return;
        
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        
        // Use popup (more reliable)
        auth.signInWithPopup(provider)
            .then(async (result) => {
                await saveUserData(result.user);
                isRedirecting = true;
                window.location.href = 'dashboard.html';
            })
            .catch((error) => {
                console.error('Google error:', error);
                if (error.code !== 'auth/popup-closed-by-user') {
                    showMessage('Google login failed');
                }
            });
    });
}

// ==================== SAVE USER DATA ====================
async function saveUserData(user) {
    try {
        await db.collection('users').doc(user.uid).set({
            email: user.email,
            displayName: user.displayName || user.email.split('@')[0],
            photoURL: user.photoURL || null,
            lastLogin: new Date().toISOString()
        }, { merge: true });
    } catch (error) {
        console.log('Could not save user data:', error);
    }
}

// ==================== AUTH STATE CHECK ====================
auth.onAuthStateChanged((user) => {
    console.log('Auth check: Current page:', window.location.pathname);
    
    // Get current page
    const isLoginPage = window.location.pathname.includes('index.html') || 
                        window.location.pathname.endsWith('/');
    const isDashboard = window.location.pathname.includes('dashboard.html');
    const isAdminPage = window.location.pathname.includes('admin-upload.html');
    
    console.log('User:', user ? user.email : 'No user');
    console.log('isLoginPage:', isLoginPage, 'isDashboard:', isDashboard);
    
    // If user is logged in AND on login page → go to dashboard
    if (user && isLoginPage) {
        console.log('Already logged in, going to dashboard');
        if (!isRedirecting) {
            isRedirecting = true;
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 100);
        }
        return;
    }
    
    // If NO user AND on dashboard/admin → go to login
    if (!user && (isDashboard || isAdminPage)) {
        console.log('Not logged in, going to login');
        if (!isRedirecting) {
            isRedirecting = true;
            window.location.href = 'index.html';
        }
        return;
    }
});

// ==================== PAGE LOAD CHECK ====================
window.addEventListener('load', () => {
    console.log('Page loaded, checking auth...');
    
    // Check if we're coming back from Google redirect
    if (window.location.hash.includes('access_token') || 
        window.location.hash.includes('authuser')) {
        console.log('Detected OAuth callback');
        // Let Firebase handle it
    }
    
    // Focus email field on login page
    if (document.getElementById('email')) {
        setTimeout(() => document.getElementById('email').focus(), 300);
    }
});

// ==================== DEBUG ====================
console.log('Auth.js loaded - No loop version');