// dashboard-auth.js - Simple auth check for dashboard
const firebaseConfig = {
    apiKey: "AIzaSyDEIJlanhg5yZ83kqFyD5uCpj2hg99a5A8",
    authDomain: "mta-web-5a05d.firebaseapp.com",
    projectId: "mta-web-5a05d",
    storageBucket: "mta-web-5a05d.firebasestorage.app",
    messagingSenderId: "203869887586",
    appId: "1:203869887586:web:fbaa16e45ffcee385cc53b",
    measurementId: "G-F4V1FJ9WDJ"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();

// Check on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('Dashboard auth check...');
    
    auth.onAuthStateChanged((user) => {
        if (!user) {
            console.log('No user on dashboard, redirecting...');
            window.location.href = 'index.html';
        } else {
            console.log('User on dashboard:', user.email);
        }
    });
});

// Logout button
if (document.getElementById('signOutBtn')) {
    document.getElementById('signOutBtn').addEventListener('click', () => {
        auth.signOut().then(() => {
            window.location.href = 'index.html';
        });
    });
}